<a href="./GUI/Help/main_en.md"><font color=#437BB5><u>Back to Homepage</u></font></a>

---
![Image](head.png)
#### V1.0 Beta


---
## About this Software

Specially designed for image leg/arm hair removal.  
<br />
![Image](intro_compare.png)  
Project link:  
<a href="https://github.com/FerryYoungFan/FanselineImageToolbox"><font color=#437BB5><u>github.com/FerryYoungFan/FanselineImageToolbox</u></font></a>  
<br />
Designed by Fanseline (@FanKetchup):&nbsp;
<a href="https://github.com/FerryYoungFan"><font color=#437BB5><u>GitHub</u></font></a>
<a href="https://twitter.com/FanKetchup"><font color=#437BB5><u>Twitter</u></font></a>
<a href="https://www.pixiv.net/users/22698030"><font color=#437BB5><u>Pixiv</u></font></a>
<br />

---
## Support this Project

If you like this software, please star this repository on GitHub.  
... or you can directly support me with money:  
<a href="https://afdian.net/@Fanseline"><font color=#437BB5><u>https://afdian.net/@Fanseline</u></font></a>

---
## Special Thanks to

香菇:&nbsp;
<a href="https://twitter.com/mushroom_0v0"><font color=#437BB5><u>twitter.com/mushroom_0v0</u></font></a>  
笈川美奈子:&nbsp;
<a href="https://www.matataki.io/user/526"><font color=#437BB5><u>matataki.io/user/526</u></font></a>

---
<a href="./GUI/Help/main_en.md"><font color=#437BB5><u>Back to Homepage</u></font></a>
