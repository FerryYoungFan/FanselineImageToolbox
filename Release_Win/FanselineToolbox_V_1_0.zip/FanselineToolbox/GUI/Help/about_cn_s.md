<a href="./GUI/Help/main_cn_s.md"><font color=#437BB5><u>返回主页</u></font></a>

---
![Image](head.png)
#### V1.0 Beta


---
## 关于本软件

专门为除去照片中腿毛等体毛而设计。  
<br />
![Image](intro_compare.png)  
项目链接:  
<a href="https://github.com/FerryYoungFan/FanselineImageToolbox"><font color=#437BB5><u>github.com/FerryYoungFan/FanselineImageToolbox</u></font></a>  
<br />
帆室邻设计 (@FanKetchup):&nbsp;
<a href="https://github.com/FerryYoungFan"><font color=#437BB5><u>GitHub</u></font></a>
<a href="https://twitter.com/FanKetchup"><font color=#437BB5><u>Twitter</u></font></a>
<a href="https://www.pixiv.net/users/22698030"><font color=#437BB5><u>Pixiv</u></font></a>
<br />

---
## 支持此项目

如果您喜欢本软件，请在GitHub给此项目打星。  
……或者您也可以直接给咱打钱：  
<a href="https://afdian.net/@Fanseline"><font color=#437BB5><u>https://afdian.net/@Fanseline</u></font></a>

---
## 特别感谢

香菇:&nbsp;
<a href="https://twitter.com/mushroom_0v0"><font color=#437BB5><u>twitter.com/mushroom_0v0</u></font></a>  
笈川美奈子:&nbsp;
<a href="https://www.matataki.io/user/526"><font color=#437BB5><u>matataki.io/user/526</u></font></a>

---
<a href="./GUI/Help/main_cn_s.md"><font color=#437BB5><u>返回主页</u></font></a>
