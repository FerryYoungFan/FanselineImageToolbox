<a href="./GUI/Help/main_cn_s.md"><font color=#437BB5><u>返回主页</u></font></a>

---
# 调整总选区
调整总掩膜（选区）的边缘和不透明度。

---

如果您想调整总选区的边缘，您可以调整以下滑块：
* 扩张选区：使总选区向四周扩张。
* 收缩选区：使总选区向中心收缩。
* 羽化边缘：使总选区边缘过渡变得平滑自然。
* 不透明度：总选区的不透明度将决定您之后使用滤镜效果时的不透明度。

<font color=#40874A>您可以同时扩张和收缩选区来填充选区中的缝隙（形态学闭运算）</font>  
<br />
![Image](selection_edit_cn_s.png)

---
<a href="./GUI/Help/main_cn_s.md"><font color=#437BB5><u>返回主页</u></font></a>
